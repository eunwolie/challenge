function startData(){
//Parse XLSX with Node to create JSON output
//using node module js-xlsx
var XLSX = require('xlsx');
var workbook = XLSX.readFile('Postal Codes.xlsx');
var sheet_name_list = workbook.SheetNames;
sheet_name_list.forEach(function(y){
  var worksheet = workbook.Sheets[y];
  var headers = {};
  var data = [];
  for(z in worksheet) {
    if(z[0] === '!') continue;
    var counter = 0;
    for (var i = 0; i < z.length; i++){
      if (!isNaN(z[i])){
        counter = i;
        break;
      }
    };
    var col = z.substring(0, counter);
    var row = parseInt(z.substring(counter));
    var value = worksheet[z].v;

    if(row == 1 && value){
      headers[col] = value;
      continue;
    }
    if(!data[row]) data[row] = {};
    data[row][headers[col]] = value;
  }

  data.shift();
  data.shift();

  // to double-check conversion
  //console.log(data);
  //stringify JSON
  stringifiedJSON = JSON.stringify(data);

  // check if postal code exists in the dataset
  var codeExists = function(stringifiedJSON, code, property){
    parsedJSON = JSON.parse(stringifiedJSON);
    for(var i = 0; i < parsedJSON.length; i += 1){
      if(parsedJSON[i].POST_CODE === code){
        return (typeof parsedJSON[i][property] !== 'undefined')
      }
    }
    // if not, return false (no highlights on calendar)
    return false;
  }

  var calculateLIs(){
    var LIRow = 0;
    $('ul li').each(function(){
      if($(this).prev().length > 0){
        if($(this).position().top != $(this).prev().position().top) return false;
        LIRow++;
      }
      else {
        LIRow++;
      }
    });
  }

  var highlightDays = function(){// check with input string
    if(codeExists(stringifiedJSON, document.getElementById('PostalCode'), 'SUNDAY')){
    // populate calendar day
      console.log("Sunday exists");
    // take all calculated rows and make sure we don't go over the calculate rows
    var counter = 1;
    calculateLIs();
    if(counter < (calculateLIs)){
      //highlight li and then add 7 for next weekdays
      $(this).css("background-color", "FFFF00");
      counter + 7;
    }


    }
    if(codeExists(stringifiedJSON, document.getElementById('PostalCode'), 'MONDAY')){
    // populate calendar day as blue
      console.log("Monday exists");
    }
    if(codeExists(stringifiedJSON, document.getElementById('PostalCode'), 'TUESDAY')){
    // populate calendar day as blue
      console.log("Tuesday exists");
    }
    if(codeExists(stringifiedJSON, document.getElementById('PostalCode'), 'WEDNESDAY')){
    // populate calendar day as blue
      console.log("Wednesday exists");
    }
    if(codeExists(stringifiedJSON, document.getElementById('PostalCode'), 'THURDAY')){
    // populate calendar day as blue
      console.log("Thursday exists");
    }
    if(codeExists(stringifiedJSON, document.getElementById('PostalCode'), 'FRIDAY')){
    // populate calendar day as blue
      console.log("Friday exists");
    }
    if(codeExists(stringifiedJSON, document.getElementById('PostalCode'), 'SATURDAY')){
    // populate calendar day as blue
      console.log("Saturday exists");
    }
  }

  console.log(highlightDays());
  // if yes, return true (yes calendar with highlighted days)

});
}
