var express = require('express');
var router = require('./routes/route');
var app = express();
var bodyParser = require('body-parser');
var path = require('path');
app.use('/assets', express.static('assets'))
app.get('/', function(req, res){
	res.sendFile(path.join(__dirname, 'index.html'));
});


app.listen(process.env.PORT || 4000, function(){
	console.log('Your node js server is running');
});
