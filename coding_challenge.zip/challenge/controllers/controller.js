var controller = {};
controller.home = function(req, res){
  if(req.postalCode !== undefined){
    return res.redirect('/')
  } else {
    return res.render('login', {succ: req.flash('succ'), error: req.flash('error')});
  }
};

controller 
